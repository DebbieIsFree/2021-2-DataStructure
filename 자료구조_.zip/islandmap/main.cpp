#include <iostream>
#include<stack>
#include <vector>
using namespace std;


void Search(int x, int y, int& cnt);


int M, N;
int map[800][800];
bool visited[800][800];


int dx[] = { 1, 0, -1, 0 };
int dy[] = { 0, -1, 0, 1 };

stack <pair<int, int>> st;

int Cx = 0, Cy = 0;

int main() {
	ios_base::sync_with_stdio(false);  cin.tie(NULL);  cout.tie(NULL);

	cin >> M >> N;
	cin.ignore();

	string s = "";
	string tmp;

	while (cin >> tmp) {
		if (tmp == "-1")
			break;

		s += tmp;
	}


	int times = s.size() / N;

	int row = 0;

	for (int i = 0; i < times; i++) {
		for (int j = 0; j < N; j++) {
			map[i][j] = s[(N * row) + j] - '0';
		}
		row++;
	}



	int count = 0;

	Search(0, 0, count);

	cout << (M * N) - count;

	return 0;
}


void Search(int x, int y, int& cnt) {

	cnt = cnt + 1;
	visited[x][y] = true;


	for (int i = 0; i < 4; i++) {
		int nx = x + dx[i];
		int ny = y + dy[i];

		if (nx < 0 || nx >= M || ny < 0 || ny >= N)
			continue;

		if (map[nx][ny] == 0 && visited[nx][ny] == 0) {
			Search(nx, ny, cnt);
		}
	}
}
